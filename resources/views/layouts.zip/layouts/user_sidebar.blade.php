<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
   <!-- Brand Logo -->
   <a href="{{url('admin/dashboard')}}" class="brand-link">
   <img src="{{asset('dist/img/AdminLTELogo.png')}}"
      alt="AdminLTE Logo"
      class="brand-image img-circle elevation-3"
      style="opacity: .8">
   <span class="brand-text font-weight-light">Costa Rica</span>
   </a>
   <!-- Sidebar -->
   <div class="sidebar">
      <!-- Sidebar user (optional) -->
      <!-- Sidebar Menu -->
      <nav class="mt-2">
         <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <li class="nav-item has-treeview ">
               <a href="{{url('user/dashboard')}}" class="nav-link {{ (request()->is('admin/dashboard')) ? 'active' : '' }}">
                  <i class="nav-icon fas fa-tachometer-alt"></i>
                  <p>
                     Dashboard
                  </p>
               </a>
            </li>
          
            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('user/bannerad*')) ? 'active' : '' }}">
                  <i class="nav-icon far fa-image"></i>
                  <p>
                     Business Ads
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('user/bannerad/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Business Ads List</p>
                     </a>
                  </li>
                 
                 
               </ul>
            </li>
                  
            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('user/classifiedsad*')) ? 'active' : '' }}">
                  <i class="nav-icon fas fa-ad"></i>
                  <p>
                     Classified Ads
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('user/classifiedsad/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Classified Ads List</p>
                     </a>
                  </li>
               </ul>
            </li>
            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('user/real-estate*')) ? 'active' : '' }}">
                   <i class="fas fa-home"></i>
                  <p>
                     Real Estate Listings
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('user/real-estate/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>                       
                        <p>Real Estate Listings</p>
                     </a>
                  </li>
                  </ul>
            </li>
            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('user/rental-property*')) ? 'active' : '' }}">
                  <i class="nav-icon fas fa-ad"></i>
                  <p>
                    Long Term Rentals
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('user/rental-property/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Long Term Rental List</p>
                     </a>
                  </li>
               </ul>
            </li>
            <li class="nav-item has-treeview ">
               <a href="{{url('user/bannerclicks/list')}}" class="nav-link {{ (request()->is('user/bannerclicks/list')) ? 'active' : '' }}">
                  <i class="nav-icon fas fa-tachometer-alt"></i>
                  <p>Business maintenance</p>
               </a>
            </li>
         </ul>
      </nav>
      <!-- /.sidebar-menu -->
   </div>
   <!-- /.sidebar -->
</aside>