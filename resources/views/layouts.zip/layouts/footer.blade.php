<footer class="main-footer">

    <div class="float-right d-none d-sm-block">

      

    </div>

    <strong>Copyright &copy; 2021<a href="{{url('admin/dashboard')}}">The Costa Rica List</a>.</strong> All rights

    reserved.

  </footer>



  <!-- Control Sidebar -->

  <aside class="control-sidebar control-sidebar-dark">

    <!-- Control sidebar content goes here -->

  </aside>

  <!-- /.control-sidebar -->

</div>

<!-- ./wrapper -->



<!-- jQuery -->


<script src="{{asset('plugins/jquery/jquery.min.js')}}"></script>

<!-- Bootstrap 4 -->

<script src="{{asset('plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

<!-- DataTables -->

<script src="{{asset('plugins/datatables/jquery.dataTables.js')}}"></script>

<script src="{{asset('plugins/datatables-bs4/js/dataTables.bootstrap4.js')}}"></script>

<!-- AdminLTE App -->
<script src="{{asset('plugins/bs-custom-file-input/bs-custom-file-input.min.js')}}"></script>

<script src="{{asset('dist/js/adminlte.min.js')}}"></script>
<!-- cropper -->
<script src="{{asset('cropper/js/cropper.js')}}"></script>
<script src="{{asset('cropper/js/main.js')}}"></script>
<!-- mulitple select -->
<script src="{{asset('Multiple-Select-Plugin/js/multi_select.js')}}"></script>


<!-- AdminLTE for demo purposes -->

<script src="{{asset('dist/js/demo.js')}}"></script>
<script src="{{asset('dist/js/custom.js')}}"></script>
<script src="{{asset('dist/js/progressbar/jquery.progressTimer.js')}}"></script>
<script src="{{asset('plugins/summernote/summernote-bs4.min.js')}}"></script>
<!-- Select2 -->
<script src="{{asset('plugins/select2/js/select2.full.min.js')}}"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.13.1/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-jcrop/2.0.4/js/Jcrop.min.js"></script>
<!-- <script src='https://www.jqueryscript.net/demo/Easy-jQuery-Progress-Bar-Timer-Plugin-For-Bootstrap-3-progressTimer/js/jquery.progressTimer.js'></script> -->


<script>
// $(document).on('keydown','input[name=phone_no], .phone_no', function(e) {
//     if (e.keyCode == 32) return false;
//     if (e.keyCode == 8 || e.keyCode == 46) return true;
// 	if(e.which < 48 || e.which > 57)
//     e.preventDefault();
// });
$(document).ready(function () {
  bsCustomFileInput.init();
  $('.cancel').on('click',function(){
    alert();
  })
});
$(document).on('keydown', 'input[type=email],input[type=Password],input[type=password]', function(e) {
    if (e.keyCode == 32) return false;
});
 
  
    function logout(event){
            event.preventDefault();
            var check = confirm("Do you really want to logout?");
            if(check){ 
               document.getElementById('logout-form').submit();
            }
     }

  

  $(function () {

    $("#example1").DataTable();

    $('#example2').DataTable({

      "paging": true,

      "lengthChange": false,

      "searching": false,

      "ordering": true,

      "info": true,

      "autoWidth": false,

    });
     // Summernote
    $('.textarea').summernote()
  $(this).on("click",".remove_this",function() { 
  // alert();
  
        var rmv_div=$(this).parent().parent().attr('class');
        // alert("rmv_div="+rmv_div);

        var str=rmv_div.trim().split(' ').pop();

        // alert("str="+str);
        var id=str.split("_").pop();  
        // alert("id="+id);      

        $("#x_"+id).val("");
        $("#y_"+id).val("");
        $("#w_"+id).val("");
        $("#h_"+id).val("");
        $("#imgstore_"+id).val("");
  
        $("."+str).remove();
   
  
  });
  $(this).on("click",".ad_delete_icon",function() { 
    
    if (confirm('Are you sure you want to delete this image?')) {
      
      var datavalue=$(this).attr("id");
        // var str=datavalue.split(" ");
        // alert(datavalue);
        var id=$("#"+datavalue).parent().parent().attr("id");
        // alert(id);        
      $("#"+id).hide();
    var del=id.split("_");
    var arr=$(".mul_del_img").val();

    var elems = [];    
    elems.push(arr);
    elems.push(del[3]);
    	$(".mul_del_img").val(elems);
    }
  });
  });

</script>

 <script type="text/javascript">
$(document).ready(function(){

            // var search = $(this).val();
          // var page = $('#hidden_page').val();
      // fetch_data(search);
      // pagination/search common function
      function fetch_data(search)
      {
          src = "{{ route('admin.userSearch') }}";
          $.ajax({

          url:src,
          type : 'POST',
          data : { search:search, "_token": "{{ csrf_token() }}"},
          success:function(data)
          {
              $('.appendTransactions').html('');
              $('.appendTransactions').append(data);
          }
          })
      }

       $(document).on('keyup', '#searchTransaction', function(){
          var search = $(this).val();
          // var page = $('#hidden_page').val();
         fetch_data(search);
       });

});




$(document).ready(function(){

  temp =$('input[name="Event_Repeat"]:checked').val();
     
    if(temp == 'on') data = 'true';
    else data='false';

    $('#repeatval').val(data);
     $('#Event_Repeat').change(function() {
        $('#repeatval').val($(this).is(':checked'));
    });

    temp =$('input[name="defaultChecked2"]:checked').val();
     
    if(temp == 'on') data = 'true';
    else data='false';

    $('#statusval').val(data);
     $('#defaultChecked2').change(function() {
        $('#statusval').val($(this).is(':checked'));
    });

   


     $("aside").hover(function(){
   $(this).addClass("dynamic_nav");
  })
  $('#phone_no_test').keypress(function(e){
    if(e.which == 97 || e.which == 98 || e.which == 99 || e.which == 110 || e.which == 111 || e.which == 65 || e.which == 66 || e.which == 67 || e.which == 78 || e.which == 79 || e.which == 49 || e.which == 50 || e.which == 51 || e.which == 52 || e.which == 53){
    } else {
      return false;
    }
  });

});

// $(document).ready(function(){
//   $('.main-sidebar').hover(function(){
// //$('.content-wrapper').addClass('new');
//   $(".select2").children('option').remove();
//   // $(".select2").css('height','0px');


//   });
//   $('.main-sidebar').mouseleave(function(){
// //$('.content-wrapper').removeClass('new');

//   });

// });


</script>

</body>

</html>