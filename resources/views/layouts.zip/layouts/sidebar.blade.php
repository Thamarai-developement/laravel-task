<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
   <!-- Brand Logo -->
   <a href="{{url('admin/dashboard')}}" class="brand-link">
   <img src="{{asset('dist/img/AdminLTELogo.png')}}"
      alt="AdminLTE Logo"
      class="brand-image img-circle elevation-3"
      style="opacity: .8">
   <span class="brand-text font-weight-light">Costa Rica</span>
   </a>
   <!-- Sidebar -->
   <div class="sidebar">
      <!-- Sidebar user (optional) -->
      <!-- Sidebar Menu -->
      <nav class="mt-2">
         <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <li class="nav-item has-treeview ">
               <a href="{{url('admin/dashboard')}}" class="nav-link {{ (request()->is('admin/dashboard')) ? 'active' : '' }}">
                  <i class="nav-icon fas fa-tachometer-alt"></i>
                  <p>
                     Dashboard
                  </p>
               </a>
            </li>
            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('admin/user*')) ? 'active' : '' }}">
                  <i class="nav-icon fas fa-user-alt"></i>
                  <p>
                     User Management
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('admin/user/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>User List</p>
                     </a>
                  </li>
               </ul>
            </li>
            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('admin/adbanner*')) ? 'active' : '' }}">
                  <i class="nav-icon far fa-image"></i>
                  <p>
                     Business Ads
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('admin/adbanner/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Business Ads List</p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="{{url('admin/adbanner/category/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Business Ads Category</p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="{{url('admin/adbanner/subscriptionCancel/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Subscription Cancel List </p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="{{url('admin/adbanner/initialuserlist')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p> Business Ads Initial User List </p>
                     </a>
                  </li>
               </ul>
            </li>
            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('admin/classifieds_ad*')) ? 'active' : '' }}">
                  <i class="nav-icon fas fa-ad"></i>
                  <p>
                     Classified Ads
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('admin/classifieds_ad/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Classified Ads List</p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="{{url('admin/classifieds_ad/category/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Classified Ads Category</p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="{{url('admin/classifieds_ad/replytoad')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Reply to Classified Ads </p>
                     </a>
                  </li>
               </ul>
            </li>
            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('admin/real-estate*')) ? 'active' : '' }}">
                   <i class="fas fa-home"></i>
                  <p>
                     Real Estate Listings
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('admin/real-estate/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>                       
                        <p>Real Estate Listings</p>
                     </a>
                  </li>
                   <li class="nav-item">
                     <a href="{{url('admin/real-estate/category/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Real Estate Category</p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="{{url('admin/real-estate/replytoad')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Reply to Real Estate Ads</p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="{{url('admin/real-estate/initialuserlist')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Real Estate Initial Email List </p>
                     </a>
                  </li>
                
               </ul>
            </li>
            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('admin/vacation*')) ? 'active' : '' }}">
                   <i class="fas fa-home"></i>
                  <p>
                     Vacation Rental
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('admin/vacation/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>                       
                        <p>Vacation Rental Listings</p>
                     </a>
                  </li>
                   <li class="nav-item">
                     <a href="{{url('admin/vacation/category/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Vaction Rental Category</p>
                     </a>
                  </li>
                
               </ul>
            </li>

            <!-- Long Term Rental Menu -->
            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('admin/rental-property*')) ? 'active' : '' }}">
                   <i class="fas fa-home"></i>
                  <p>
                     Long Term Rentals
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('admin/rental-property/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>                       
                        <p>Long Term Listings</p>
                     </a>
                  </li>
                   <li class="nav-item">
                     <a href="{{url('admin/rental-property/category/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Long Term Rental Category</p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="{{url('admin/rental-property/replytoad')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Reply to Long Term Rental Ads</p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="{{url('admin/rental-property/initialuserlist')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p> Long Term Rental  Initial Email List </p>
                     </a>
                  </li>
                
               </ul>
            </li>


            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('admin/event*')) ? 'active' : '' }}">
                  <i class="nav-icon fas fa-tachometer-alt"></i>
                  <p>
                     Event Management
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('admin/event/category/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Event Category</p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="{{url('admin/event/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Event List</p>
                     </a>
                  </li>
               </ul>
            </li>

            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('admin/province*')) ? 'active' : '' }}">
                   <i class="fas fa-map-marked-alt"></i>
                  <p>
                     Province & City 
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('admin/province/create')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>                       
                        <p>Add Province & City</p>
                     </a>
                  </li>
                   <li class="nav-item">
                     <a href="{{url('admin/province/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Province & City Listings</p>
                     </a>
                  </li>
                
               </ul>
            </li>

            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('admin/package*')) ? 'active' : '' }}">
                  <i class="nav-icon far fa-image"></i>
                  <p>
                  Packages  
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('admin/package/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Packages List</p>
                     </a>
                  </li>
                 
               </ul>
            </li>

            
            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('admin/province*')) ? 'active' : '' }}">
                   <i class="fas fa-map-marked-alt"></i>
                  <p>
                     WordPress Management
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('blog/wp-login.php')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>                       
                        <p>Articles</p>
                     </a>
                  </li>
                   
                
               </ul>
            </li>
            <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('admin/forum*')) ? 'active' : '' }}">
                  <i class="nav-icon fas fa-comments"></i>
                  <p>
                     Forum Management
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('admin/forum/category/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Forum Category</p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="{{url('admin/forum/post/list/0')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Forum Posts</p>
                     </a>
                  </li>
               </ul>
            </li>
            <!-- <li class="nav-item has-treeview">
               <a href="#" class="nav-link {{ (request()->is('admin/articles*')) ? 'active' : '' }}">
                  <i class="nav-icon fas fa-newspaper"></i>
                  <p>
                     Articles Management
                     <i class="right fas fa-angle-left"></i>
                  </p>
               </a>
               <ul class="nav nav-treeview">
                  <li class="nav-item">
                     <a href="{{url('admin/articles/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Articles List</p>
                     </a>
                  </li>
                  <li class="nav-item">
                     <a href="{{url('admin/articles/category/list')}}" class="nav-link">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Articles Category</p>
                     </a>
                  </li>
               </ul>
            </li> -->
            <li class="nav-item has-treeview ">
               <a href="{{url('admin/bannerclicks/list')}}" class="nav-link {{ (request()->is('admin/bannerclicks/list')) ? 'active' : '' }}">
                  <i class="nav-icon fas fa-tachometer-alt"></i>
                  <p>Business maintenance</p>
               </a>
            </li>
            <li class="nav-item has-treeview ">
               <a href="{{URL('admin/myprofile/'.Auth::user()->id)}}" class="nav-link {{ (request()->is('admin/myprofile/'.Auth::user()->id)) ? 'active' : '' }}">
                  <i class="nav-icon fas fa-user-alt"></i>
                  <p>My Profile</p>
               </a>
            </li>
            <li class="nav-item has-treeview ">
               <a href="{{URL('/admin/changepassword')}}" class="nav-link {{ (request()->is('admin/changepassword')) ? 'active' : '' }}">
                  <i class="nav-icon fas fa fa-key"></i>
                  <p>Change password</p>
               </a>
            </li>
         </ul>
      </nav>
      <!-- /.sidebar-menu -->
   </div>
   <!-- /.sidebar -->
</aside>