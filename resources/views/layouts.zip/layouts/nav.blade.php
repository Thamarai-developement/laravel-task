<!-- Navbar -->

  <nav class="main-header navbar navbar-expand navbar-dark">
  <!-- <nav class="main-header navbar navbar-expand navbar-white navbar-light"> -->


    <!-- Left navbar links -->

    <ul class="navbar-nav">

      <li class="nav-item">

        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>

      </li>

      <li class="nav-item sitetitle">

        <a href="#">Costa Rica</a>

      </li>

      

    </ul>



  


    <!-- Right navbar links -->

    <ul class="navbar-nav ml-auto">

       <li class="nav-item">
      <div class="user-panel mt-3 pb-3 mb-3 d-flex profile">
<!--         <div class="image">
          @if(Auth::user()->image !="")

              <img src="{{URL('/')}}/upload/thumbuser/{{Auth::user()->image}}" class="img-circle elevation-2" alt="User Image">

          @else

              <img src="{{URL('/')}}/projectAssets/profile.png" width="120px" height="120px" style=" border-radius: 50%;"/>

          @endif
          
        </div> -->
        <div class="info prf_name">
          <a href="{{URL('admin/user/edit/'.Auth::user()->id)}}" class="d-block">{{ucfirst(Auth::user()->name)}}</a>
        </div>
      </div>
      </li>
       <li class="nav-item">

        <a class="nav-link" href="{{ route('admin.logout') }}" onclick="return logout(event);" id="logout">

          <i class="fas fa-sign-out-alt"></i>
          

        </a>
          <form id="logout-form" action="{{ route('admin.logout') }}" method="POST"
       style="display: none;">
       {{ csrf_field() }}
   </form>

      </li>


    </ul>
 
  </nav>
  
  <!-- /.navbar -->

